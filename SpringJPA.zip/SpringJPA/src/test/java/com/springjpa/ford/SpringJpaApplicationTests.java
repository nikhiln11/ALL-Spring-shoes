package com.springjpa.ford;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}

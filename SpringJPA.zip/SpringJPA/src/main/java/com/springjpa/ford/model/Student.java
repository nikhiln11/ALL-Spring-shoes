package com.springjpa.ford.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Student {
    
    @Id
    int id;
    String name;
    String collegeName;
    int marks;
    public Student(int id, String name, String collegeName, int marks) {
        super();
        this.id = id;
        this.name = name;
        this.collegeName = collegeName;
        this.marks = marks;
    }
    public Student() {
        super();
        // TODO Auto-generated constructor stub
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getCollegeName() {
        return collegeName;
    }
    public void setCollegeName(String collegeName) {
        this.collegeName = collegeName;
    }
    public int getMarks() {
        return marks;
    }
    public void setMarks(int marks) {
        this.marks = marks;
    }
    
    
    
    
}
